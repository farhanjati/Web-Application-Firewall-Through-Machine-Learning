# Fwaf-Machine-Learning-driven-Web-Application-Firewall

![Alt text](firewall_fsecurify.jpg?raw=true "Fsecurify")
Machine learning driven web application firewall to detect malicious queries with high accuracy.

Link:
http://fsecurify.com/fwaf-machine-learning-driven-web-application-firewall/
