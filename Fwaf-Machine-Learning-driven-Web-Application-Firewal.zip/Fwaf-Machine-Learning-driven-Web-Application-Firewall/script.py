'Tugas Besar ET4047'

'Andi Muhammad Y.P.C. - 18118012'
'Muhammad Farhan Jati - 18118017'
'Daffa Alun Sagara    - 18118038'
 

import os
import urllib
import urllib.request
import urllib.parse
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn import metrics

'Mendefiniskan fungsi token sebagai 3 ngrams.'

def getNGrams(query):
	tempQuery = str(query)
	ngrams = []
	for i in range(0,len(tempQuery)-3):
		ngrams.append(tempQuery[i:i+3])
	return ngrams

 

'Load dasaet queries.'

filename = 'badqueries.txt'
directory = str(os.getcwd())
filepath = directory + "/" + filename
data = open(filepath,'r', encoding="utf8").readlines()
data = list(set(data))
badQueries = []
validQueries = []
count = 0
for d in data:
	d = str(urllib.parse.unquote(d).encode('utf8').decode('utf8')) 
	badQueries.append(d)

filename = 'goodqueries.txt'
directory = str(os.getcwd())
filepath = directory + "/" + filename
data = open(filepath,'r').readlines()
data = list(set(data))
for d in data:
	d = str(urllib.parse.unquote(d).encode('utf8').decode('utf8')) 
	validQueries.append(d)

badQueries = list(set(badQueries))
validQueries = list(set(validQueries))
AllQueries = badQueries + validQueries
bady = [1 for i in range(0,len(validQueries))]
goody = [0 for i in range(0,len(badQueries))]
y = bady+goody
queries = AllQueries

vectorizer = TfidfVectorizer(tokenizer=getNGrams) #converting data to vectors
X = vectorizer.fit_transform(queries)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

lgs = LogisticRegression(max_iter=9999999)
lgs.fit(X_train, y_train)
print(lgs.score(X_test, y_test))

predicted = lgs.predict(X_test)

fpr, tpr, _ = metrics.roc_curve(y_test, (lgs.predict_proba(X_test)[:, 1]))
auc = metrics.auc(fpr, tpr)

badCount = len(badQueries)
validCount = len(validQueries)

print("Bad samples: %d" % badCount)
print("Good samples: %d" % validCount)
print("Baseline Constant negative: %.6f" % (validCount / (validCount + badCount)))
print("------------")
print("Accuracy: %f" % lgs.score(X_test, y_test))  #checking the accuracy
print("Precision: %f" % metrics.precision_score(y_test, predicted))
print("Recall: %f" % metrics.recall_score(y_test, predicted))
print("F1-Score: %f" % metrics.f1_score(y_test, predicted))
print("AUC: %f" % auc)